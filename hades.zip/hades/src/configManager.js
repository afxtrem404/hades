const editJsonFile = require('edit-json-file');

const file = editJsonFile(`${__dirname}/../config.json`);

function setConfig(path, config) {
  return file.set(path, config) && file.save();
}

function getConfig(path) {
  return {
    ...file.get(path),
    set: (config) => setConfig(path, config),
  };
}

module.exports = {
  setConfig,
  getConfig,
};
