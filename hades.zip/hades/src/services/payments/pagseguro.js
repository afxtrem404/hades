const { bot } = require('../../bot')
const { PIX } = require('gpix/dist')
const { AwesomeQR } = require('awesome-qr')

const json = require('edit-json-file')

const fs = require('fs')
const request = require('request-promise')
const randexp = require('randexp')
const database = require('../../database')

const DataBaseFunctions = require('../../class')

const { Transactions, User } = database

const channels = [process.env.GIFTS_LOG_CHANNEL]

class PagSeguroPix {
  constructor(credentials) {
    this.key_cert = credentials.key_cert
    this.pem_cert = credentials.pem_cert
    this.client_id = credentials.client_id
    this.client_secret = credentials.client_secret
    this.key = credentials.key
    this.revision = 0
  }

  async api(options) {
    const body = JSON.stringify({
      grant_type: 'client_credentials',
      scope: 'pix.read pix.write cob.read cob.write',
    })

    const credentialsToken = Buffer.from(
      `${this.client_id}:${this.client_secret}`
    ).toString('base64')

    const config = {
      method: 'POST',
      url: 'https://secure.api.pagseguro.com/pix/oauth2',
      headers: {
        Authorization: `Basic ${credentialsToken}`,
        'Content-Type': 'application/json',
      },
      timeout: 15000,
      cert: fs.readFileSync(this.pem_cert),
      key: fs.readFileSync(this.key_cert),
      body: body,
      pool: { maxSockets: 1024 },
    }

    const response = JSON.parse(
      await request(config).catch((error) =>
        JSON.stringify(error?.error ?? { ...error })
      )
    )

    const bearer = response?.access_token

    if (!bearer) return response

    return request({
      headers: {
        Authorization: `Bearer ${bearer}`,
        'Content-Type': 'application/json',
      },
      timeout: config.timeout,
      cert: config.cert,
      key: config.key,
      pool: config.pool,
      ...options,
    }).catch((error) => error?.message ?? `${error}`)
  }

  async createPixBilling(options) {
    const txId = new randexp(/^[a-zA-Z0-9]{26,35}$/)
      .gen()
      .toUpperCase()

    const body = {
      ...options,
      chave: this.key,
    }
    const _this = this
    const createPixBilling = JSON.parse(
      await this.api({
        method: 'PUT',
        url: `https://secure.api.pagseguro.com/instant-payments/cob/${txId}`,
        body: JSON.stringify(body),
      })
    )

    return {
      response: createPixBilling,
      pixQrcode: () => {
        return _this.genQrCode(createPixBilling)
      },
      checkBilling: () => {
        return _this.checkBilling(createPixBilling)
      },
      reviseBilling: (config) => {
        return _this.reviseBilling(createPixBilling, config)
      },
      pay: (config) => {
        return _this.pay(createPixBilling, config)
      },
    }
  }

  async genQrCode(pixData) {
    console.log(pixData)
    let dpix = PIX.dinamic()
      .setReceiverName('Pagseguro Internet SA')
      .setReceiverCity('SAO PAULO')
      .setLocation(pixData.location)
      .setAmount(Number(pixData.valor.original))

    const text = dpix.getBRCode()
    const dir = `${__dirname}/../../temp/pix-backgrounds/bg.jpg`
    const background = fs.readFileSync(dir)

    const buffer = await new AwesomeQR({
      text: text,
      size: 520,
      logoScale: 0.9,
      margin: 1.5,
      backgroundImage: background,
    }).draw()

    return {
      copyPast: text,
      qrCode: buffer,
    }
  }

  checkBilling({ txid }) {
    return this.api({
      method: 'GET',
      url: `https://secure.api.pagseguro.com/instant-payments/cob/${txid}?revisao=${this.revision}`,
    })
  }

  reviseBilling({ txid }, config = {}) {
    this.revision = 1
    return this.api({
      method: 'PATCH',
      url: `https://secure.api.pagseguro.com/instant-payments/cob/${txid}`,
      body: JSON.stringify(config),
    })
  }

  static async verifyPayment(body) {
    const [payment] = body

    const txId = payment.txId
    const amount = parseFloat(payment.valor)

    const transaction = await database.Transactions.findOne({
      provider: 'pagseguro',
      'data.status': 'ATIVA',
      'data.txid': txId,
    }).populate('payer')

    if (!transaction) return

    transaction.data = payment

    await database.User.findOneAndUpdate(
      {
        id: transaction.payer.id,
      },
      { $inc: { credits: amount } }
    )
    await transaction.save()

    await bot.sendMessage(
      transaction.payer.id,
      `✅ <b>Pagamento recebido.</>\n` +
        `<b>Valor:</> <code>R$${amount}</>\n` +
        `<b>Sua recarga foi creditada em sua conta, use /rank para ver seu saldo.</>`,
      {
        parse_mode: 'HTML',
      }
    )

    const notifyRecharge = (channel) =>
      bot
        .sendMessage(
          channel,
          `✅ <b>Recarga realizada (PIX)!</b>\n\n` +
            `<b>Usuário</b>: <code>${transaction.payer.name}</code>\n` +
            `<b>Id:</b> <code>${transaction.payer.id}</code>\n` +
            `<b>Valor:</b> <code>R$${amount}</>`,
          { parse_mode: 'HTML' }
        )
        .catch(console.log)

    channels.forEach(notifyRecharge)
  }
}

class PagseguroWorkArround {
  constructor(token) {
    this.token = token
  }

  getTransactions(days = 0) {
    return request({
      url: `https://mb.api.pagseguro.uol/statement?daysBefore=${days}`,
      method: 'get',
      headers: {
        'user-agent':
          'PagSeguro release/4.19.4 (br.com.uol.ps.myaccount; build:311; Android 8.1.0',
        'x-token': this.token,
      },
    })
  }

  async createPayment({ user, amount, expiration }) {
    const transaction = new Transactions({
      type: 'pix',
      provider: 'gambiarra',
      data: {
        amount,
        expiration,
        type: 'PIX_CREATED',
      },
      payer: user._id,
    })

    await transaction.save()

    return transaction
  }

  async verifyPayment(user, payment) {
    const addNumber = () => {
      const file = json(`${__dirname}/../../../../pix.json`, {
        autosave: true,
      })

      const numbers = file.get()

      const number = payment.data.amount.split('.').pop()

      numbers.push(parseFloat(`0.${number}`))

      file.set('', numbers)
    }

    const paymentAmount = payment.data.amount

    const timer = () =>
      setTimeout(async () => {
        const now = new Date()

        if (now > new Date(payment.data.expiration)) {
          console.log('Pagamento expirado')

          addNumber()

          return Promise.resolve()
        }

        const transactions = await this.getTransactions().catch(
          (error) => ({
            error: true,
            errorMessage: error,
          })
        )

        if (transactions.error) {
          console.log('Erro na consulta da transacao: ', transactions)
          return timer()
        }

        const { statementCheckingAccount } = JSON.parse(transactions)

        if (!statementCheckingAccount.length) return timer()

        const transaction =
          statementCheckingAccount[0].statementMovement.find(
            (current) => {
              const amount = current.value
                .replace(/[^0-9,]/g, '')
                .replace(',', '.')

              return (
                amount == paymentAmount &&
                (current.type == 'PIX_RECEIVED' ||
                  current.type == 'PIX_INTERNAL_TPZ' ||
                  current.type == 'PIX_INTERNAL_IN')
              )
            }
          )

        console.log('Pagamento: ', transaction)

        if (!transaction) return timer()

        const exists = await Transactions.exists({
          provider: 'gambiarra',
          'data.operationId': transaction.checkingAccountOperationId,
        })

        console.log('Pagamento existe: ', exists)

        if (exists) return timer()

        await User.findOneAndUpdate(
          {
            _id: user._id,
          },
          {
            $inc: {
              credits: parseFloat(paymentAmount),
              current_transactions: -1,
            },
          }
        )

        await bot.sendMessage(
          user.id,
          `✅ <b>Pagamento recebido.</>\n` +
            `<b>Valor:</> <code>R$${paymentAmount}</>\n\n` +
            `<b>Sua recarga foi creditada em sua conta.</>`,
          {
            parse_mode: 'HTML',
          }
        )

        payment.data.operationId =
          transaction.checkingAccountOperationId
        payment.data.type = transaction.type

        await Transactions.updateOne(
          { _id: payment._id },
          {
            data: payment.data,
          }
        )

        const notifyRecharge = (channel) =>
          notifier
            .sendMessage(
              channel,
              `✅ <b>Recarga realizada!</b>\n\n` +
                `<b>Usuário</b>: <code>${user.name}</code>\n` +
                `<b>Id:</b> <code>${user.id}</code>\n` +
                `<b>Valor:</b> <code>R$${paymentAmount}</>` +
                `\n<b>Saldo atual</>: <code>R$${
                  user.credits + parseFloat(paymentAmount)
                }</>` +
                `\n<b>Saldo anterior</>: <code>R$${user.credits}</>\n` +
                `<b>Provedor:</> <code>gambiarra</>`,
              { parse_mode: 'HTML' }
            )
            .catch(Function())

        channels.forEach(notifyRecharge)

        addNumber()

        console.log('Pagamento recebido: ', payment)
      }, 60000 * 3)

    timer()
  }
}

module.exports = { PagSeguroPix, PagseguroWorkArround }
