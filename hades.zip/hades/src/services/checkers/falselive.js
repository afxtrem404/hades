const { getConfig } = require('../../configManager')
const { setTimeout } = require('timers/promises')

module.exports = async function falselive(card) {
  const { falselive: configs } = getConfig('checkers')
  const delay = 3000

  await setTimeout(delay)

  return {
    card,
    live: true,
    active: true,
    output: {},
  }
}
