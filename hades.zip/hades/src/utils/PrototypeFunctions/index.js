Array.prototype.shuffle = function() {
    var currentIndex = this.length, temporaryValue, randomIndex
      while (0 !== currentIndex) {
        randomIndex = Math.floor(Math.random() * currentIndex)
        currentIndex --
        temporaryValue = this[currentIndex]
        this[currentIndex] = this[randomIndex]
        this[randomIndex] = temporaryValue
      }
        return this
}

Array.prototype.spliter = function(){
    var indice = 0, arr = []
        for(let i = 0; i < this.length; i ++){
            if(!arr[indice]) arr[indice] = []
                arr[indice].push(this[i])
            if(arr[indice].length == 2) indice ++
        }
        return arr
    }


String.prototype.capitalizeFirstLetter = function() {
    return this.charAt(0).toUpperCase() + this.slice(1)
}


const luhn = function (number) {
  return number.split('').map((digit, index, arr) => (index % 2 !== arr.length % 2) ? parseInt(digit, 10) : 2 * digit
  ).reduce(function sum(val, cur, idx, arr) {
      return val + (cur < 10 ? parseInt(cur, 10) : (String(cur).split('').reduce(sum, 0)))
     }, 0) % 10
}
String.prototype.luhn = function () {
  return luhn(this) === 0
}

Function.sleep = function(ms) {
  return new Promise((resolve) => {
    setTimeout(resolve, ms)
  })
} 
