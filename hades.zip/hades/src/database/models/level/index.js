'use strict'

const mongoose = require('mongoose')

const Schema = mongoose.Schema
var schema = new Schema({
    type: {
        required: true,
        unique: true,
        type: String
    },
    price: {
        type: String,
        required: true
    },
    alternative_price: {
        type: String,
        required: true
    },
    total_cards: {
        type: Number,
        required: true
    }
}, {timestamps: true})

schema.virtual('cards', {
    ref: 'Cards',
    localField: '_id',
    foreignField: 'level'
})

schema.set('toObject', {virtuals: true})
schema.set('toJSON', {virtuals: true})
		
module.exports = schema