'use strict'

const mongoose = require('mongoose')

const Schema = mongoose.Schema
const schema = new Schema(
  {
    type: {
      type: String,
      required: true,
    },
    provider: {
      type: String,
      required: true,
    },
    data: {
      type: Object,
      required: true,
    },
    payer: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
  },
  { timestamps: true }
)

module.exports = schema
