require('../../utils/PrototypeFunctions')
const Checker = require('../../checker')

class Level {
  constructor(db, message) {
    this.Level = db.Level
    this.Cards = db.Cards
    this.message = message
    this.checker = new Checker(db)
  }

  async adicionarCartoes(lista) {
    //niveis predefinidos
    const levels = {
      'NÃO ENCONTRADO': ['A combinar', 'A combinar'],
    }

    const schemes = [
      'AMERICAN EXPRESS',
      'ELO/DISCOVER',
      'ELO',
      'HIPERCARD',
      'MISTERIOSA',
    ]

    const banks = ['BANCO C6 SA', 'NUBANK', 'MISTERIOSA']

    for (const card of lista) {
      const {
        card: { number, month, year, cvv },
        bin: { brand: level = 'MISTERIOSA' },
        bin,
      } = card

      const isFull = card.card?.holderName && card.card?.holderCpf

      const [price, alternative_price] = levels[level.toUpperCase()]
        ? levels[level.toUpperCase()]
        : ['A combinar', 'A combinar']

      const bank = banks.find((b) => {
        const bk = bin.bank?.name?.includes?.('NÃO ENCONTRADO')
          ? 'MISTERIOSA'
          : bin.bank
          ? bin.bank.name
          : 'MISTERIOSA'

        return bk == b
      })

      let scheme = schemes.find((s) => {
        const sh = bin.scheme?.includes?.('NÃO ENCONTRADO')
          ? 'MISTERIOSA'
          : bin.scheme
          ? bin.scheme
          : 'MISTERIOSA'
        return sh == s
      })

      scheme = ['ELO/DISCOVER'].includes(bin.scheme)
        ? 'GRAPHITE'
        : bin?.scheme?.includes?.('6505')
        ? 'ELO'
        : scheme

      const levelType = scheme
        ? scheme
        : bank
        ? bank
        : level
        ? level
        : 'MISTERIOSA'

      const customLevel = isFull ? `FULL ${levelType}` : levelType

      const exists = await this.Level.exists({
        type: customLevel,
      })

      if (exists) {
        try {
          const Level = await this.Level.findOneAndUpdate(
            {
              type: customLevel,
            },
            { $inc: { total_cards: 1 } },
            { new: true }
          )

          var newCard = new this.Cards()
          newCard.number = number
          newCard.month = month
          newCard.year = year
          newCard.cvv = cvv
          newCard.restrict = false
          newCard.bin = bin
          newCard.name = 'Nome do portador'
          newCard.cpf = '000.000.000-00'
          newCard.level = Level._id
          newCard.purshased = 0

          if (isFull) {
            newCard.full = true
            newCard.holderName = card.card.holderName
            newCard.holderCpf = card.card.holderCpf
          }

          await newCard.save()
        } catch (e) {
          console.log('Erro ao editar cartão/nivel: ', e.message)
        }
      } else {
        try {
          var newLevel = new this.Level()
          newLevel.type = customLevel
          newLevel.price = price
          newLevel.alternative_price = alternative_price
          newLevel.total_cards = 1

          console.log(newLevel)
          console.log(card)

          let savedLevel = await newLevel.save()

          var newCard = new this.Cards()
          newCard.number = number
          newCard.month = month
          newCard.year = year
          newCard.cvv = cvv
          newCard.restrict = false
          newCard.bin = bin
          newCard.name = 'Nome do portador'
          newCard.cpf = '000.000.000-00'
          newCard.level = savedLevel._id
          newCard.purshased = 0

          if (isFull) {
            newCard.full = true
            newCard.holderName = card.card.holderName
            newCard.holderCpf = card.card.holderCpf
          }
          await newCard.save()

          //console.log('Cartão e nivel salvos.')
        } catch (e) {
          console.log('Erro ao salvar cartão/nivel: ', e.message)
        }
      }
    }
  }

  async niveisDisponiveis() {
    try {
      let levels = await this.Level.find({}).populate({
        path: 'cards',
        match: {
          restrict: false,
        },
      })

      levels = levels.filter((lvl) => lvl.cards.length >= 1)

      if (levels.length > 0) {
        return {
          success: true,
          response: levels,
        }
      } else {
        return {
          success: false,
          response: '<b>Nenhum cartão disponível</b>',
        }
      }
    } catch (e) {
      return {
        success: false,
        response: e.message,
      }
    }
  }

  async nivel(nivel) {
    try {
      var level = await this.Level.findOne({ type: nivel })
      return level
    } catch (e) {
      return e.message
    }
  }

  async pegarCartoes(level, check = false, filter = false) {
    try {
      const lvl = await this.Level.findOne({ type: level }).populate({
        path: 'cards',
      })
      const startTime = Date.now()

      let returnMessage = 'Nenhum cartão disponível'
      let cartoes = lvl.cards
        .filter((card) => {
          const validation = filter
            ? !card.restrict && filter(card)
            : !card.restrict
          return validation
        })
        .shuffle()

      if (check) {
        let cards = []
        let checkedCards = []

        for (let cartao of cartoes) {
          checkedCards.push(cartao)
          const response = await this.checker.check(cartao)
          const endTime = (Date.now() - startTime) / 1000

          if (endTime >= 300) {
            returnMessage =
              'Compra cancelada. Tempo excedido, verifique a disponibilidade do checker e tente novamente...'
            break
          }

          if (response.success && response.live) {
            cards.push(cartao)
            break
          } else if (!response.success) {
            cards = cartoes.slice(checkedCards.length, cartoes.length)
            break
          }
        }

        cartoes = cards
      }
      if (!cartoes.length)
        return {
          success: false,
          response: returnMessage,
        }

      return {
        success: true,
        response: cartoes,
      }
    } catch (e) {
      return {
        success: false,
        response: e.message,
      }
    }
  }

  async restringirCartao(card, id = 0) {
    try {
      const cartao = await this.Cards.findOneAndUpdate(
        { number: card },
        { restrict: true, purshased: id },
        { new: true }
      ).populate('level')
      const level = await this.Level.findOneAndUpdate(
        { type: cartao.level.type },
        { $inc: { total_cards: -1 } }
      )

      return {
        success: true,
        response: cartao,
      }
    } catch (e) {
      return {
        success: false,
        response: e.message,
      }
    }
  }

  async anexarDados(card, dados) {
    try {
      const { name, cpf } = dados
      const cartao = await this.Cards.findOneAndUpdate(
        { number: card },
        { cpf: cpf, name: name },
        { new: true }
      ).populate('level')

      return {
        success: true,
        response: cartao,
      }
    } catch (e) {
      return {
        success: false,
        response: e.message,
      }
    }
  }

  async removerCartao(card) {
    try {
      const cartao = await this.Cards.deleteOne({
        number: card.number,
      })

      return {
        success: true,
        response: card,
      }
    } catch (e) {
      return {
        success: false,
        response: e.message,
      }
    }
  }

  async editarNivel(level, prices) {
    try {
      const exists = await this.Level.exists({ type: level })

      if (exists) {
        const lvl = await this.Level.findOneAndUpdate(
          { type: level },
          { price: prices[0], alternative_price: prices[1] },
          { new: true }
        )

        return {
          success: true,
          response: `<i>${lvl.type}</i> <b>editado com sucesso.</b>`,
        }
      } else {
        return {
          success: false,
          response: '<b>Nível não encontrado</b>',
        }
      }
    } catch (e) {
      return {
        success: false,
        response: e.message,
      }
    }
  }
}

module.exports = Level
