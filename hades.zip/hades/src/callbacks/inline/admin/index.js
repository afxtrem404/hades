require('../../../utils/PrototypeFunctions')

class Callback {
  constructor(bot, data, Db = {}) {
    this.bot = bot
    this.data = data
    this.Db = Db
  }

  async menuEditarUsuario() {
    const callbackid = this.data.id
    const { response: user } = await this.Db.user().informacoes()

    const restringir = user.restrict
      ? '🚫 Desfazer'
      : '🚫 Restringir Usuário'
    const admin = user.admin ? '👮‍♀️ Desfazer' : '👮‍♀️ Admin'

    var menuEditOptions = {
      message: `<b>Nome:</b> <code>${
        user.name
      }</code>\n<b>Id: </b><code>${
        user.id
      }</code>\n<b>Conta restrita</b>: <code>${
        user.restrict ? 'sim' : 'não'
      }</code>\n<b>Admin: </b><code>${
        user.admin ? 'sim' : 'não'
      }</code>\n<b>Saldo: </b><code>R$${
        user.credits
      }</code>\n<b>Cartões: </b><code>${
        user.shopping.cards
      }</code>\n<b>Gifts: </b><code>${user.shopping.gifts}</code>`,
      options: {
        parse_mode: 'html',
        inline_message_id: this.data.inline_message_id,
        reply_markup: {
          inline_keyboard: [
            [
              {
                text: restringir,
                callback_data: 'restringirUsuario',
              },
            ],
            [
              {
                text: admin,
                callback_data: 'promoverUsuario',
              },
            ],
            [
              {
                text: '⬇️ Cartões do Usuário',
                callback_data: 'cartoesDoUsuario',
              },
            ],
            [
              {
                text: '🔙 Voltar',
                callback_data: 'voltarMenuEdicao',
              },
            ],
          ],
        },
      },
    }

    return menuEditOptions
  }
  async deletarUsuario() {
    const callbackid = this.data.id

    var deleteOptions = {
      message: `<b>Deseja deletar este usuário?</b>`,
      options: {
        parse_mode: 'html',
        inline_message_id: this.data.inline_message_id,
        reply_markup: {
          inline_keyboard: [
            [
              {
                text: '✅ Confirmar',
                callback_data: 'confirmarDeletarUsuario',
              },
            ],
            [
              {
                text: '❌ Cancelar',
                callback_data: 'cancelarDeletar',
              },
            ],
          ],
        },
      },
    }

    return deleteOptions
  }

  async cartoesDoUsuario() {
    const callbackid = this.data.id

    try {
      const getHistoric = await this.Db.user().baixarHistorico()
      const { response: user } = await this.Db.user().informacoes()

      if (getHistoric.success) {
        await this.bot.sendChatAction(
          this.data.from.id,
          'upload_document'
        )
        await this.bot.sendDocument(
          this.data.from.id,
          `${__dirname}/../../../class/user/users/${user.id}.txt`,
          { caption: `Histórico de ${user.name}` }
        )
        this.bot.answerCallbackQuery(callbackid, {
          text: 'Download bem sucedido.',
          show_alert: true,
        })

        require('fs').unlink(
          `${__dirname}/../../../class/user/users/${user.id}.txt`,
          (err) => console.log(err)
        )
      } else {
        this.bot.answerCallbackQuery(
          callbackid,
          'Ocorreu um erro ao realizar o download de seu histórico.'
        )
      }
    } catch (e) {
      this.bot.answerCallbackQuery(
        callbackid,
        'Ocorreu um erro ao realizar o download de seu histórico.'
      )
    }
  }

  async confirmarDeletarUsuario() {
    var deleteOptions = {
      message: `<b>Usuário deletado.</b>`,
      options: {
        parse_mode: 'html',
        inline_message_id: this.data.inline_message_id,
      },
    }

    try {
      const deleteUser = await this.Db.user().deletarConta()

      this.bot.answerCallbackQuery(this.data.id, {
        text: 'Usuário deletado com sucesso.',
        show_alert: true,
      })

      return deleteOptions
    } catch (e) {
      deleteOptions.message = `<b>Ocorreu uma falha ao exluir este usuário.</b>`

      return deleteOptions
    }
  }

  async confirmarRestringirUsuario() {
    var restrictUser = {
      message: `<b>Usuário restringido.</b>`,
      options: {
        parse_mode: 'html',
        inline_message_id: this.data.inline_message_id,
      },
    }

    try {
      const restringirUsuario =
        await this.Db.user().restringirUsuario()

      if (restringirUsuario.success) {
        this.bot.answerCallbackQuery(this.data.id, {
          text: 'Usuário restringido com sucesso.',
          show_alert: true,
        })
      } else {
        deleteOptions.message = `<b>Ocorreu uma falha ao restringir este usuário.</b>`
        return restrictUser
      }

      return restrictUser
    } catch (e) {
      deleteOptions.message = `<b>Ocorreu uma falha ao restringir este usuário.</b>`
      return restrictUser
    }
  }
  async restringirUsuario() {
    const { response: user } = await this.Db.user().informacoes()
    const callbackid = this.data.id

    if (user.restrict) {
      await this.Db.user().reativarConta()
      this.bot.answerCallbackQuery(callbackid, {
        text: 'Restrinção removida.',
        show_alert: true,
      })
      return await this.menuEditarUsuario()
    }

    var deleteOptions = {
      message: `<b>Deseja restringir este usuário?</b>`,
      options: {
        parse_mode: 'html',
        inline_message_id: this.data.inline_message_id,
        reply_markup: {
          inline_keyboard: [
            [
              {
                text: '✅ Confirmar',
                callback_data: 'confirmarRestringirUsuario',
              },
            ],
            [
              {
                text: '❌ Cancelar',
                callback_data: 'cancelarRestringir',
              },
            ],
          ],
        },
      },
    }

    return deleteOptions
  }

  async deleteGift() {
    var deleteGiftOptions = {
      message: '<b>Gift deletado.</b>',
      options: {
        parse_mode: 'html',
        inline_message_id: this.data.inline_message_id,
      },
    }

    const [, gift] = this.data.data.split('_')
    const delGift = await this.Db.gift().delete(gift)

    return deleteGiftOptions
  }

  async promoverUsuario() {
    const { response: user } = await this.Db.user().informacoes()
    const callbackid = this.data.id

    if (user.admin) {
      await this.Db.user().despromoverUsuario()
      this.bot.answerCallbackQuery(callbackid, {
        text: 'Usuário despromovido.',
        show_alert: true,
      })
      return await this.menuEditarUsuario()
    }

    var promoteOptions = {
      message: `<b>Deseja promover este usuário á admin?\n\n</b><i>Quando um usuário é promovido à admin, ele terá acesso a todos os comandos da store.</i>`,
      options: {
        parse_mode: 'html',
        inline_message_id: this.data.inline_message_id,
        reply_markup: {
          inline_keyboard: [
            [
              {
                text: '✅ Confirmar',
                callback_data: 'confirmarPromoverUsuario',
              },
            ],
            [
              {
                text: '❌ Cancelar',
                callback_data: 'cancelarPromover',
              },
            ],
          ],
        },
      },
    }

    return promoteOptions
  }

  async confirmarPromoverUsuario() {
    var promoteUser = {
      message: `<b>Usuário promovido à admin.</b>`,
      options: {
        parse_mode: 'html',
        inline_message_id: this.data.inline_message_id,
      },
    }

    try {
      const promoverUsuario = await this.Db.user().promoverUsuario()

      if (promoverUsuario.success) {
        this.bot.answerCallbackQuery(this.data.id, {
          text: 'Usuário promovido com sucesso.',
          show_alert: true,
        })
      } else {
        promoteUser.message = `<b>Ocorreu uma falha ao promover este usuário.</b>`
        return promoteUser
      }

      return promoteUser
    } catch (e) {
      promoteUser.message = `<b>Ocorreu uma falha ao promover este usuário.</b>`
      return promoteUser
    }
  }

  async menu() {
    const { response: user } = await this.Db.user().informacoes()

    const menuOptions = {
      message: `<b>Nome:</b> <code>${
        user.name
      }</code>\n<b>Id: </b><code>${
        user.id
      }</code>\n<b>Conta restrita</b>: <code>${
        user.restrict ? 'sim' : 'não'
      }</code>\n<b>Saldo: </b><code>R$${
        user.credits
      }</code>\n<b>Cartões: </b><code>${
        user.shopping.cards
      }</code>\n<b>Gifts: </b><code>${user.shopping.gifts}</code>`,
      options: {
        parse_mode: 'html',
        inline_message_id: this.data.inline_message_id,
        reply_markup: {
          inline_keyboard: [
            [
              {
                text: '✏️ Editar usuário',
                callback_data: 'editarUsuario',
              },
            ],
            [
              {
                text: '🗑 Deletar usuário',
                callback_data: 'deletarUsuario',
              },
            ],
          ],
        },
      },
    }

    return menuOptions
  }

  async callbackType(data) {
    //const data = this.data.data
    try {
      const types = {
        deletarUsuario: () => this.deletarUsuario(),
        cartoesDoUsuario: async () => this.cartoesDoUsuario(),
        editarUsuario: async () => this.menuEditarUsuario(),
        restringirUsuario: async () => this.restringirUsuario(),
        promoverUsuario: async () => this.promoverUsuario(),
        deleteGift: async () => this.deleteGift(),

        confirmarDeletarUsuario: async () =>
          this.confirmarDeletarUsuario(),
        confirmarRestringirUsuario: async () =>
          this.confirmarRestringirUsuario(),
        confirmarPromoverUsuario: async () =>
          this.confirmarPromoverUsuario(),

        voltarMenuEdicao: async () => this.menu(),
        cancelarDeletar: async () => this.menu(),
        cancelarRestringir: async () => this.menuEditarUsuario(),
        cancelarPromover: async () => this.menuEditarUsuario(),
      }

      if (!types[data] && !data.includes('deleteGift')) return

      const { message, options } = types[data]
        ? await types[data]()
        : data.includes('deleteGift')
        ? await types.deleteGift()
        : 0

      this.bot.editMessageText(message, options)
    } catch (e) {
      //console.log(e.message)
    }
  }
}

module.exports = Callback
